import{d as o,g as t,h as n,j as r,o as a}from"./index-DVNi33c_.js";const p=o({__name:"reload",setup(s){const e=n();return t(()=>{e.go(-1)}),(c,u)=>(a(),r("div"))}});export{p as default};
